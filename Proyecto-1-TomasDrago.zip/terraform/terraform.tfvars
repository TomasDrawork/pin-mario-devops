aws_region           = "us-east-1"
project_name         = "mario-rpg"
vpc_cidr             = "10.0.0.0/16"
public_subnet_cidrs  = ["10.0.1.0/24", "10.0.2.0/24"]
private_subnet_cidr  = "10.0.10.0/24"
instance_type        = "t3.micro"
